
import React from 'react';

const PawIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm3.5 12c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm-3-4c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm-4 4c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3-8c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>
    <path fill="none" d="M0 0h24v24H0z"/>
    <path d="M12.83 9.17c-.78-.78-2.05-.78-2.83 0-1.17 1.17-.43 3.59 1.41 3.59s2.58-2.42 1.42-3.59z"/>
    <path d="M7.5 13c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>
    <path d="M16.5 13c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>
    <path d="M12 18c-1.93 0-3.5-1.57-3.5-3.5 0-.5.11-.98.31-1.42.18-.39.49-.69.85-.85.44-.2.92-.31 1.42-.31.2 0 .4.02.59.05.51.1 1 .33 1.41.74.41.41.64.9.74 1.41.03.19.05.39.05.59C15.5 16.43 13.93 18 12 18z"/>
  </svg>
);

const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md shadow-md sticky top-0 z-10">
      <div className="max-w-4xl mx-auto py-3 px-4 flex items-center space-x-3">
        <PawIcon className="text-cyan-600" />
        <h1 className="text-2xl font-bold text-slate-800">
          Dr. <span className="text-cyan-600">Pet</span>
        </h1>
      </div>
    </header>
  );
};

export default Header;
