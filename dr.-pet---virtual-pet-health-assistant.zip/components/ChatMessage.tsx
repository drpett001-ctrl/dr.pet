
import React from 'react';
import { Message, Role } from '../types';

interface ChatMessageProps {
  message: Message;
}

const UserIcon: React.FC = () => (
    <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-500 flex-shrink-0">
        U
    </div>
);

const ModelIcon: React.FC = () => (
    <div className="w-8 h-8 rounded-full bg-cyan-100 flex items-center justify-center text-cyan-700 flex-shrink-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
            <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM8.267 6.393a.75.75 0 0 1 .43-1.047 3.744 3.744 0 0 1 3.592.51 3.745 3.745 0 0 1 3.592-.51.75.75 0 0 1 .43 1.047 2.245 2.245 0 0 0-.256 1.137 2.25 2.25 0 0 0 4.238 1.132.75.75 0 0 1 1.047.43 3.745 3.745 0 0 1-.51 3.592 3.745 3.745 0 0 1 .51 3.592.75.75 0 0 1-1.047.43 2.25 2.25 0 0 0-4.238 1.132c.08.43-.016.883-.256 1.137a.75.75 0 0 1-.43 1.047 3.745 3.745 0 0 1-3.592-.51 3.745 3.745 0 0 1-3.592.51.75.75 0 0 1-.43-1.047c-.24-.254-.336-.707-.256-1.137a2.25 2.25 0 0 0-4.238-1.132.75.75 0 0 1-1.047-.43 3.745 3.745 0 0 1 .51-3.592 3.745 3.745 0 0 1-.51-3.592.75.75 0 0 1 1.047-.43 2.25 2.25 0 0 0 4.238-1.132c-.08-.43.016-.883.256-1.137Z" clipRule="evenodd" />
        </svg>
    </div>
);


const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === Role.USER;
  
  const containerClasses = isUser ? 'bg-white' : 'bg-cyan-50/50';
  const messageFlexClasses = isUser ? 'flex-row' : 'flex-row';

  return (
    <div className={`p-4 ${containerClasses}`}>
        <div className={`max-w-4xl mx-auto flex gap-4 ${messageFlexClasses}`}>
            {isUser ? <UserIcon /> : <ModelIcon />}
            <div className="flex-1 pt-0.5">
                 <p className="text-slate-800 whitespace-pre-wrap leading-relaxed">
                    {message.text}
                 </p>
            </div>
        </div>
    </div>
  );
};

export default ChatMessage;
