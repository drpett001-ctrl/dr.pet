
import React, { useState, useEffect, useRef } from 'react';
import type { Chat } from '@google/genai';
import { Message, Role } from './types';
import { startDrPetChat } from './services/geminiService';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import LoadingSpinner from './components/LoadingSpinner';

const App: React.FC = () => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  useEffect(() => {
    async function initializeChat() {
      try {
        setIsLoading(true);
        const chatSession = startDrPetChat();
        setChat(chatSession);

        const initialResponse = await chatSession.sendMessageStream({ message: "Hello!" });
        
        let fullText = "";
        const initialMessageId = Date.now().toString();

        setMessages([{ id: initialMessageId, role: Role.MODEL, text: '...' }]);

        for await (const chunk of initialResponse) {
          fullText += chunk.text;
          setMessages(prev => prev.map(m => m.id === initialMessageId ? {...m, text: fullText} : m));
        }

      } catch (e) {
        setError("Failed to initialize Dr. Pet. Please check your API key and refresh.");
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    }
    initializeChat();
  }, []);

  const handleSendMessage = async (userMessage: string) => {
    if (!chat) return;

    const userMsgId = Date.now().toString();
    const modelMsgId = (Date.now() + 1).toString();

    setMessages(prev => [
      ...prev,
      { id: userMsgId, role: Role.USER, text: userMessage },
    ]);
    setIsLoading(true);
    setError(null);

    try {
        const stream = await chat.sendMessageStream({ message: userMessage });
        
        let fullText = "";
        setMessages(prev => [
            ...prev,
            { id: modelMsgId, role: Role.MODEL, text: '' },
        ]);

        for await (const chunk of stream) {
            fullText += chunk.text;
            setMessages(prev => prev.map(m => m.id === modelMsgId ? {...m, text: fullText} : m));
        }
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Oops! Something went wrong. ${errorMessage}`);
      setMessages(prev => prev.filter(m => m.id !== modelMsgId));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 font-sans">
      <Header />
      <main className="flex-1 overflow-y-auto">
        <div className="flex flex-col">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
          ))}
           {isLoading && messages.length > 0 && <div className="p-4 bg-cyan-50/50"><div className="max-w-4xl mx-auto flex gap-4"><LoadingSpinner /></div></div>}
           <div ref={chatEndRef} />
        </div>
         {error && (
            <div className="p-4 bg-red-50">
                <div className="max-w-4xl mx-auto flex gap-4 items-center">
                    <p className="text-red-700 font-semibold">{error}</p>
                </div>
            </div>
        )}
      </main>
      <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default App;
